<?php
$DB['server'] = 'db';
//$DB['server'] = '127.0.0.1';
$DB['port'] = '3306';
$DB['user'] = 'phpmyfaq';
$DB['password'] = 'phpmyfaq';
$DB['db'] = 'phpmyfaq';
$DB['prefix'] = '';
$DB['type'] = 'pdo_mysql';
