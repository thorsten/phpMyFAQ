<?php

const AAD_OAUTH_TENANTID = 'bcf95d9f-4c05-406d-9379-78278e227b3c';
const AAD_OAUTH_CLIENTID = '80596a6e-748d-492f-a6d1-535ddba8f9fb';
const AAD_OAUTH_SECRET = 'o0O8Q~P5R1XOOOyuXD3unBQYY59nwHytKN1iAdkn';
const AAD_OAUTH_SCOPE = 'openid%20offline_access%20profile%20user.read';
